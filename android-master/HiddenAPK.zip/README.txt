Proiect create de: Zaharia Costin Alexandru
Email: zaharia.c.alexandru@gmail.com
Github: zahariaca
Student anul II ISM

Proiectul a fost create pentru Android 4.4 API 19
Testat cu: AVD Nexus 4 API 19

Instructiunile pentru cum a fost creat .png se afla in StepsToEncryptDecrypt.txt